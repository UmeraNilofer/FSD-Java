package com.example.SpringBootWith_Docker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWithDockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
